package com.egg.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "discount_details")
public class DiscountDeatails implements Serializable {

	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int discountId;
	@Column
	private String discountCode;
	private Double discountPercentage;
	@JsonFormat(pattern = "dd-mm-yyyy")
	private Date startdate;
	@JsonFormat(pattern = "dd-mm-yyyy")
	private Date enddate;
	
	public DiscountDeatails() {
		
	}

	public DiscountDeatails(int discountId, String discountCode, Double discountPercentage, Date startdate,
			Date enddate) {
		super();
		this.discountId = discountId;
		this.discountCode = discountCode;
		this.discountPercentage = discountPercentage;
		this.startdate = startdate;
		this.enddate = enddate;
	}

	public int getDiscountId() {
		return discountId;
	}

	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}

	public String getDiscountCode() {
		return discountCode;
	}

	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}

	public Double getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(Double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	@Override
	public String toString() {
		return "DiscountDeatails [discountId=" + discountId + ", discountCode=" + discountCode + ", discountPercentage="
				+ discountPercentage + ", startdate=" + startdate + ", enddate=" + enddate + "]";
	}
	
	
	
}
