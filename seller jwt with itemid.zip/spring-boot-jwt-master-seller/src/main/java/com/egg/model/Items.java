package com.egg.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name="items_details")
public class Items implements Serializable{

	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	 private int itemid;
	 private String categoryid;
	 private String subcategoryid;
	 @Column
	 private Double  itemCost;
	 private String itemName;
	 private String itemDescription;
	 private int quantity;
	 private String model;
	 private String manfacture;
	// private int sellerid;
	 @ManyToOne
	 @JoinColumn(name = "sellerId", nullable = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	 private Seller seller;
	 public Items() {
		 
	 }

	

	public Items(int itemid, String categoryid, String subcategoryid, Double itemCost, String itemName,
			String itemDescription, int quantity, String model, String manfacture, Seller seller) {
		super();
		this.itemid = itemid;
		this.categoryid = categoryid;
		this.subcategoryid = subcategoryid;
		this.itemCost = itemCost;
		this.itemName = itemName;
		this.itemDescription = itemDescription;
		this.quantity = quantity;
		this.model = model;
		this.manfacture = manfacture;
		this.seller = seller;
	}



	public int getItemid() {
		return itemid;
	}

	public void setItemid(int itemid) {
		this.itemid = itemid;
	}

	public String getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(String categoryid) {
		this.categoryid = categoryid;
	}

	public String getSubcategoryid() {
		return subcategoryid;
	}

	public void setSubcategoryid(String subcategoryid) {
		this.subcategoryid = subcategoryid;
	}

	public Double getItemCost() {
		return itemCost;
	}

	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getManfacture() {
		return manfacture;
	}

	public void setManfacture(String manfacture) {
		this.manfacture = manfacture;
	}
	
	

	public Seller getSeller() {
		return seller;
	}



	public void setSeller(Seller seller) {
		this.seller = seller;
	}



	@Override
	public String toString() {
		return "Items [itemid=" + itemid + ", categoryid=" + categoryid + ", subcategoryid=" + subcategoryid
				+ ", itemCost=" + itemCost + ", itemName=" + itemName + ", itemDescription=" + itemDescription
				+ ", quantity=" + quantity + ", model=" + model + ", manfacture=" + manfacture + ", seller=" + seller
				+ "]";
	}


}