import { Component, OnInit } from '@angular/core';
import { Seller } from '../seller';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-sellersignup',
  templateUrl: './sellersignup.component.html',
  styleUrls: ['./sellersignup.component.css']
})
export class SellersignupComponent implements OnInit {


  constructor(private pService:ProductService) { }

  ngOnInit(): void {
  }

  
  




}
