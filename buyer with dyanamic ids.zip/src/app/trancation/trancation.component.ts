import { Component, OnInit } from '@angular/core';
import { ViewCart } from '../cart';
import { Transcation } from '../transcation';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-trancation',
  templateUrl: './trancation.component.html',
  styleUrls: ['./trancation.component.css']
})
export class TrancationComponent implements OnInit {
  
  viewcart:ViewCart=new ViewCart();
  transcation:Transcation[];
 
  transcations:Transcation=new Transcation();


  constructor( private pService:ProductService) { }

 

  ngOnInit(): void {
    console.log(this.transcation);
  }

  onSubmit(){

    this.transcations.remarks="Payment Sucessfull";
     
    this.pService.makeTranscation(this.transcations).subscribe( transcations => this.transcations=transcations);

  }
  

}
