export class Buyer{
    buyerID:number;
    username:string;
    password:string;
    emailId:string;
    mobileNumber:string;
    // "dd-mm-yyyy"
   // createdDate:string;

}