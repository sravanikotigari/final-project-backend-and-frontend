import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My-App';

  pnam ="this is testing";

  pnam1=1;
  myfunc(){
    this.pnam1++;
  }
  pnam2=1;
  myfunc2(){
    this.pnam2--;
  }
 

  // myfunc(){

  //   console.log("suceesfully clicked");
  // }
}
