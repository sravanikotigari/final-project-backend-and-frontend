import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pqr',
  templateUrl: './pqr.component.html',
  styleUrls: ['./pqr.component.css']
})
export class PqrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
