import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pavan',
  templateUrl: './pavan.component.html',
  styleUrls: ['./pavan.component.css']
})
export class PavanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
