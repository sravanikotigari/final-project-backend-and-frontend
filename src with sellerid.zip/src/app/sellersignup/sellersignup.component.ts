import { Component, OnInit } from '@angular/core';

import { ApiService } from '../service/api.service';
import { Router } from '@angular/router';
import { Seller } from '../model/seller';



@Component({
  selector: 'app-sellersignup',
  templateUrl: './sellersignup.component.html',
  styleUrls: ['./sellersignup.component.css']
})
export class SellersignupComponent implements OnInit {



  seller: Seller= new Seller();
  
  submitted=false;
  constructor( private apiservice:ApiService,private router:Router) { }

  ngOnInit(): void {
  }
  newSeller(): void{

    this.submitted=false;
    //this.seller=new Seller();
    this.router.navigate(['app']);
 }
 save() {

  this.apiservice.createSeller(this.seller)
  .subscribe(data =>console.log(data),error => console.log(error));  
}
onSubmit(){

  this.submitted =true;
  this.save();

}




}
