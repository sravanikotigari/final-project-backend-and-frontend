import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../model/item';
import { ApiService } from '../service/api.service';

@Component({
  selector: 'app-additemdetail',
  templateUrl: './additemdetail.component.html',
  styleUrls: ['./additemdetail.component.css']
})
export class AdditemdetailComponent implements OnInit {

  @Input()

  product:Product;

 constructor(private pSservice:ApiService) { }

 ngOnInit(): void {
 }


}
