import { Component } from '@angular/core';
import { ApiService } from './service/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular8-demo';

constructor(private apiservice:ApiService,private router:Router){

}

display(){

this.router.navigate(['sellersignup'])


}


}
